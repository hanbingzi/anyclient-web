-- 
SELECT  address from  sys_manager;

select  name  from sys_role;

SELECT * from sys_manager GROUP BY sex;

insert into  ;  

-- 
SELECT * FROM test.;
SELECT * FROM test1.;

-- aa
select * from sys_user_role t1 left JOIN sys_user t2 on t1.role_id=t2.user_id;

select * from test.