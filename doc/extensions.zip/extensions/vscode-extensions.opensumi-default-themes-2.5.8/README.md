<p align="center">
  <img width="200" src="https://github.com/opensumi/Default-Themes/raw/HEAD/icons/icon.png">
</p>

<h1 align="center">OpenSumi Default Themes</h1>

### OpenSumi Dark Theme
![Dark Theme](https://github.com/opensumi/Default-Themes/raw/HEAD/snapshots/sumi-default-dark.png)

### OpenSumi Light Theme
![Light Theme](https://github.com/opensumi/Default-Themes/raw/HEAD/snapshots/sumi-default-light.png)

### VS Code

[Install from VS Marketplace](https://marketplace.visualstudio.com/items?itemName=opensumi.opensumi-default-themes)

![Sumi Themes For VS Code](https://github.com/opensumi/Default-Themes/raw/HEAD/snapshots/sumi-vs.png)
